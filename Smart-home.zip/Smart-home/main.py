import sys
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5 import QtGui
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from smarthome import Ui_smart
from test import turn_relay_off,turn_relay_on


class smart(QMainWindow):
    def __init__(self):
        super().__init__()
        self.u=Ui_smart()
        self.u.setupUi(self)
        self.u.pushButton.clicked.connect(self.on)
        self.u.pushButton_2.clicked.connect(self.ona)
        self.u.pushButton_3.clicked.connect(self.off)
        self.u.pushButton_4.clicked.connect(self.offa)
        self.u.pushButton_5.clicked.connect(self.back)
        self.u.movie = QtGui.QMovie("C:\\Users\\sujay\\Desktop\\python\\Ai Assistant\\Resources\\digitalloop.gif")
        self.u.label.setMovie(self.u.movie)
        self.u.movie.start()
        self.showMaximized()

    def on(self):
        turn_relay_on()
    def ona(self):
        turn_relay_on()
    def off(self):
        turn_relay_off()
    def offa(self):
        turn_relay_off()



app = QApplication(sys.argv)
window = smart()
window.show()
sys.exit(app.exec_())